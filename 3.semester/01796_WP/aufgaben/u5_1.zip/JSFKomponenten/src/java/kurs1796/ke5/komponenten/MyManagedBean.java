package kurs1796.ke5.komponenten;

import java.io.IOException;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;


@Named
@RequestScoped
public class MyManagedBean {
    
    // Deklaration der Properties
    private String vorname;
    private String nachname;
    
    private String name;

    // Getter- und Setter-Methoden
    public MyManagedBean() {
    }

    public String getVorname() {
        return vorname;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    public String getNachname() {
        return nachname;
    }

    public void setNachname(String nachname) {
        this.nachname = nachname;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    // Diese Methode wird beim Klick auf den Submit-Button aufgerufen
    public void absenden()
    {
        // Der zusammengesetzte Name wird erzeugt
        setName(vorname + " " + nachname);
        
        try
        {
            // Die ManagedBean leitet den Anwender auf die JSF-Seite result.xhtml weiter
            FacesContext.getCurrentInstance().getExternalContext().dispatch("result.xhtml");
        }
        catch (IOException e)
        {
            // Wenn ein Fehler auftritt, wird dieser in der Konsole ausgegeben
            System.out.println("Fehler aufgetreten: " + e.getMessage());
        }
    }
}
