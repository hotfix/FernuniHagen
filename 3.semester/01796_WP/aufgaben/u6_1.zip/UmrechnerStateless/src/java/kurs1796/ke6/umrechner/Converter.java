
package kurs1796.ke6.umrechner;

import java.math.BigDecimal;
import javax.ejb.Stateless;


// Wir definieren eine Stateless Session Bean, da wir keine Daten speichern möchten
@Stateless
public class Converter
{
    // Wir definieren den Umrechnungskurs (Euro-Dollar) als Konstante
    private final BigDecimal EUROKURS = new BigDecimal(1.3170);
    
    // Business-Methode zum Umrechnen von Dollar nach Euro
    public BigDecimal dollarZuEuro(BigDecimal dollar) {
        return dollar.divide(EUROKURS, 2, BigDecimal.ROUND_HALF_UP);
    }
    
    // Business-Methode zum Umrechnen von Euro nach Dollar
    public BigDecimal euroZuDollar(BigDecimal euro) {
        BigDecimal dollar = euro.multiply(EUROKURS);
        return dollar.setScale(2, BigDecimal.ROUND_HALF_UP);
    }
}
