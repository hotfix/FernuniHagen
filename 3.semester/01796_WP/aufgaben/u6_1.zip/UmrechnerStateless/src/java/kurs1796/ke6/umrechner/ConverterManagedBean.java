

package kurs1796.ke6.umrechner;

import java.math.BigDecimal;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;


@Named
@RequestScoped
public class ConverterManagedBean
{
    // Hier wird Dependency Injection genutzt, damit der EJB-Container des
    // Java EE-Servers automatisch eine Instanz unserer EJB-Klasse "Converter"
    // erzeugt. Mit Hilfe der Variable "bean" können wir anschließend auf
    // diese Instanz zugreifen
    @EJB private Converter bean;
    
    // Variablen für die Eingabe und die beiden Ergebniswerte
    private BigDecimal eingabe;
    private BigDecimal dollar;
    private BigDecimal euro;
    
    // Diese Methode wird über die Schaltfläche der JSF-Seite aufgerufen
    // Sie berechnet zu der Eingabe des Benutzers, beide Ergebniswerte
    public void berechne() {
        dollar = bean.euroZuDollar(eingabe);
        euro = bean.dollarZuEuro(eingabe);
    }

    // Getter- und Setter-Methoden
    public BigDecimal getEingabe() {
        return eingabe;
    }

    public void setEingabe(BigDecimal eingabe) {
        this.eingabe = eingabe;
    }

    public BigDecimal getDollar() {
        return dollar;
    }

    public void setDollar(BigDecimal dollar) {
        this.dollar = dollar;
    }

    public BigDecimal getEuro() {
        return euro;
    }

    public void setEuro(BigDecimal euro) {
        this.euro = euro;
    }
}
