
package statefulcart;


/*
    Die Klasse "Book". Ein Buch wird durch einen Autor und einen Titel
    beschrieben.
*/
public class Book {
    
    // Deklaration der Properties
    private String author;
    private String title;
    
    // Getter- und Setter-Methoden
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    // Der Konstruktor der Klasse über den direkt der Autor
    // und der Titel des neuen Buches angegeben werden können
    public Book(String author, String title)
    {
        this.author = author;
        this.title = title;
    }
    
    // Hier wird die Methode toString der Java-Klasse "Object" überschrieben
    // Wir geben hier einfach den Titel und den Autor des Buches aus
    // in Form "Buch: (Der Titel von Mr X)"
    @Override
    public String toString()
    {
        return "Buch: (" + this.title + "  von  " + this.author + ")";
    }

}
