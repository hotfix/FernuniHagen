
package statefulcart;


import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;


@Named
@SessionScoped
public class ManagedCartBean implements Serializable {

    // An dieser Stelle wird unsere Stateful Session Bean mit Hilfe
    // von Dependency Injection injiziert
    @EJB
    private StatefulCartBean shoppingCart;
    
    // Deklaration der Properties
    private String author;
    private String title;
    
    // Ruft die Methode getBooks unserer EJB auf und holt gibt
    // somit alle bisher erstellten Bücher zurück
    public List<Book> getBooks()
    {
        return shoppingCart.getBooks();
    }
    
    // Ruft die Methode addBook unserer EJB auf und übergibt ihr ein neues
    // Objekt der Klasse Book
    public void addBook()
    {
        shoppingCart.addBook(new Book(author, title));
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    
}
