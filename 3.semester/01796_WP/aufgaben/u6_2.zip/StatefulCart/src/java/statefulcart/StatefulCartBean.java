
package statefulcart;


import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateful;

// Die EJB muss mit "Stateful" annotiert werden, damit für jeden Client eine
// eigenes Objekt erzeugt wird.
@Stateful
public class StatefulCartBean {

    // Liste aller für den jeweiligen Client bereits erzeugten Bücher
    private List<Book> books = new ArrayList<>();
    
    // Liefert alle Bücher
    public List<Book> getBooks()
    {
        return this.books;
    }
    
    // Fügt ein neues Buch hinzu
    public void addBook(Book book)
    {
        if (book != null)
            this.books.add(book);
    }
    
}
